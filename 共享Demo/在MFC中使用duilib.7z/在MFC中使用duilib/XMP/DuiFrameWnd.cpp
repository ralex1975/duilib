#include "stdafx.h"
#include "DuiFrameWnd.h"
#include "XMPDlg.h"

#define IDC_BUTTON_DUI_NEXT 2000

CDuiFrameWnd::CDuiFrameWnd( LPCTSTR pszXMLPath, CXMPDlg *pDlgMain )
: CXMLWnd(pszXMLPath),
m_pDlgMain(pDlgMain)
{
    CPaintManagerUI::SetInstance(AfxGetInstanceHandle());                    // ָ��duilib��ʵ��
    CPaintManagerUI::SetResourcePath(CPaintManagerUI::GetInstancePath());    // ָ��duilib��Դ��·��������ָ��Ϊ��exeͬĿ¼
}

CDuiFrameWnd::~CDuiFrameWnd()
{
}

void CDuiFrameWnd::OnFinalMessage( HWND hWnd )
{
    delete this;
}

CControlUI* CDuiFrameWnd::CreateControl( LPCTSTR pstrClassName )
{
    if (_tcsicmp(pstrClassName, _T("Wnd")) == 0)
    {
        CWndUI *pUI = new CWndUI;   
        HWND   hWnd = CreateWindow(_T("BUTTON"), _T("Next"), WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 0, 0, 0, 0, m_PaintManager.GetPaintWindow(), (HMENU)IDC_BUTTON_DUI_NEXT, NULL, NULL);
        pUI->Attach(hWnd);  
        return pUI;
    }

    return NULL;
}

LRESULT CDuiFrameWnd::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch (uMsg)
    {
    case WM_COMMAND:
        if (IDC_BUTTON_DUI_NEXT == wParam)
        {
            if (m_pDlgMain)
            {
                m_pDlgMain->OnBnClickedButtonPlayNext();
            }
        }
        break;
    default:
        break;
    }

    return __super::HandleMessage(uMsg, wParam, lParam);
}

void CDuiFrameWnd::Notify( TNotifyUI& msg )
{
    if (m_pDlgMain)
    {
        if( msg.sType == _T("click") ) 
        {
            if( msg.pSender->GetName() == _T("btnPrevious") ) 
            {
                m_pDlgMain->OnBnClickedButtonPlayPrevious();
            }
            else if( msg.pSender->GetName() == _T("btnNext") ) 
            {
                m_pDlgMain->OnBnClickedButtonPlayNext();
            }
            else if( msg.pSender->GetName() == _T("btnPlay") ) 
            {
                m_pDlgMain->OnBnClickedButtonPlay();
            }
        }
    }

    __super::Notify(msg);
}

void CDuiFrameWnd::SetMainDialog( CXMPDlg *pDlgMain )
{
    m_pDlgMain = pDlgMain;
}

