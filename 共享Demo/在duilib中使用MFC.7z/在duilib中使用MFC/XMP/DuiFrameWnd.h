#pragma once
#include "duilib.h"

class CXMPDlg;
class CDuiFrameWnd: public CXMLWnd
{
public:
    explicit CDuiFrameWnd(LPCTSTR pszXMLPath, CXMPDlg *pDlgMain = NULL);

protected:
    virtual ~CDuiFrameWnd();

private:
    CXMPDlg *m_pDlgMain;    // MFC���ڵ�ָ��

public:
    virtual void OnFinalMessage(HWND hWnd);
    virtual void Notify(TNotifyUI& msg);
    virtual CControlUI* CreateControl(LPCTSTR pstrClassName);
    virtual LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

    void SetMainDialog(CXMPDlg *pDlgMain);  // ����MFC�����ڵ�ָ��
};